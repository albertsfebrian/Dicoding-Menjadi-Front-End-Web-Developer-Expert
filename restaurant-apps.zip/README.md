# Dicoding-Menjadi-Front-End-Web-Developer-Expert
Submission Project Dicoding dengan materi [Menjadi Front-End Web Developer Expert](https://www.dicoding.com/academies/219).


Kriteria
- [x] Responsive (Media query dan Grid)
- [x] Experiencing Focus & Screen Reader
- [x] Navigation Bar, Hero, List Restoran, Footer

Saran Submission
- [x] Pemilihan Warna
- [x] Tata Letak
- [x] Font
- [x] Penerapan Padding dan Margin tepat
- [x] Layout Responsive
- [x] Konten Tambahan (City List)
- [x] Penggunaan Element tepat
- [x] SASS
